<?php
$showAlert = false;
$showError = false;

$con=mysqli_connect("localhost","root","mera@sqlioplkj","online mart");
if(!$con)
die("could not connected");
if(isset($_POST["place"])){
$n1=$_POST["PI"];
  $n2=$_POST["PN"];
  $n3=$_POST["PP"];
  $n4=$_POST["semail"];
  $n5=$_POST["uemail"];
  $n6=$_POST["name"];
  $n7=$_POST["tel"];
  $n8=$_POST["qty"];
  $n9=$_POST["add"];
  $n10=$_POST["pc"];
  $n11=$_POST["pic"];
 $s="insert into orderproduct  values('".$n1."','".$n2."','".$n3."','".$n4."','".$n5."','".$n6."',
 '".$n7."','".$n8."','".$n9."','".$n10."','".$n11."',
 current_timestamp())";
  
  $no=mysqli_query($con,$s);
  if($no!=0){
    
  $showAlert = true;


  
  }
    else 
    $showError = "did not place order ! Try again";
  }

  
  
 
 




    




?>
<!doctype html>
<html>
    <head>
<?php 

include_once("head.php");
?>
</head>
<body >
  
<?php 
include_once("nav.php");

?>
<?php
    if($showAlert){
    echo '
    <div class="container" style="position:relative;top:10%">
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Your Order is successful .. 
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div> </div>' ;
    }
    if($showError){
    echo '
    <div class="container" style="position:relative;top:10%">
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error!</strong> '.$showError.' 
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div> </div> ';
    }
    ?>

<?php


$con=mysqli_connect("localhost","root","mera@sqlioplkj","online mart");
if(!$con)
die("could not connected");
if(isset($_POST["po"]) && isset($_SESSION["email"]) ){
$pi=$_POST["pid"];
$email=$_POST["email"];
$price=$_POST["price"];
$name=$_POST["name"];
$pic=$_POST["pic"];












    


?>
<div class="container" style="position:relative;top:10px">
<div class="text-center"><h3>Fill the detail to proceed</h3></div>

<form action="order.php" method="post">
  <div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input type="text" name="name" required class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Name">
    </div>

    <div class="form-group">
    <label for="exampleInputEmail1">Contact Number</label>
    <input type="tel" required maxlength="10" name="tel" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter 10 digit Mobile number">
    </div>

    <div class="form-group">
    <label for="exampleInputEmail1">Quantity</label>
    <input type="number" step=1 min=1 max=5 required name="qty" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Quantity  (max 5 can be ordered)">
    </div>

    <div class="form-group">
    <label for="exampleInputEmail1">Street Details</label>
    <input type="text" name="add" required class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Location Address">
    </div>

    

    <div class="form-group">
    <label for="exampleInputEmail1">Pin Code</label>
    <input type="text" name="pc" maxlength="6" required class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Valid Pin Code">
    </div>
    
    <div class="form-group">
    <label for="exampleInputEmail1">Order Amount</label>
    <input type="text"  required class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" readonly value="<?php echo $price ?>">
    </div>
    <input type="hidden" name="PI" value="<?php echo $pi; ?>">
  <input type="hidden" name="PP" value="<?php echo $price ?>">
  <input type="hidden" name="semail" value="<?php echo $email ?>">
  <input type="hidden" name="PN" value="<?php echo $name ?>">
  <input type="hidden" name="uemail" value="<?php echo $_SESSION["email"]; ?>">
  
  <input type="hidden" name="pic" value="<?php echo $pic; ?>">
  <button type="submit" name="place" class="btn " style="background:blue;color:white">Place Order</button>
</form>
</div>
<?php
}
if(!isset($_SESSION["email"])){
    echo '
    <div class="container" style="position:relative;top:200px ;text-align:center;font-weight:900;font-size:20px">
    <div class="alert alert-success alert-dismissible fade show" text-center role="alert" >
    <strong>sorry!</strong> You are not logged in
   
</div></div> ';
}
?>


<?php
include_once("js.php");

?>

</body>

    </html>