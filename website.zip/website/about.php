<!DOCTYPE html>
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<?php include_once("head.php");?>

</head>
<body  >

<?php include_once("nav.php") ; ?>

  
<div class="container"style="position:relative;top:30%;margin-bottom:50px;" >
<div class="row ">

<div  class=" col-lg-12 " style="text-align:center ;">
<button id="btn" class=" btn  animate__animated animate__zoomInDown  animate__delay-1s" style="background:rgba(68, 18, 248, 200);
padding:0.5rem;width:500px;border:1px solid gray">
<h6 class="animate__animated animate__slideInLeft  animate__delay-2s" style="color:white;font-weight:900">Click here To know about us</h6></button>
<div id="dis" style="display:none"  class="row">
<div class="col-lg-12 "><h2 class="animate__animated animate__zoomInDown  animate__delay-0.5s" style="text-align:center;font-weight:800;color:rgba(68, 18, 248, 200)">About Us</h2></div>
</div>


<p id="di" class="card animate__animated animate__zoomInDown   animate__delay-1s  " style="color:rgba(68, 18, 248, 200);border:1px solid gray;border-radius:1.5rem;border-bottom-right-radius:1.5rem;text-align:justify;text-transform:captailize;display:none;padding:5%">We serve the best across the country .our door to door sevice getting progressed day by day and encouraging our entire 
members of our <b style="text-transform:uppercase"> my mall family</b> </p>
</div>
</div>

</div>

<script >
$(document).ready(function(){
  $("#btn").click(function(){
     $("#dis"). show();
     $("#di"). show();
     $("#btn").hide();
  });
});

</script>
<?php include_once("js.php");?> 
</body>

</html>

