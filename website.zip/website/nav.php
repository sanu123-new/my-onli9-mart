


<header>
<?php 
 session_start();
if(isset($_SESSION["email"])  ){
  echo '  <nav class="navbar navbar-expand-lg   fixed-top" style="background:rgba(68, 18, 248, 200)">
 <div style="border-right:0.5px solid gray"> <a style="color:white;font-size:30px;line-height:1em;font-weight:900" class="navbar-brand" href="#"><img class="img img-responsive logo animate__animated animate__bounce animate__infinite infinite" height=60px width=50px src="image/OIP.jfif" alt=""> &nbsp; Onli9 Mart</a></div>
  <button class="navbar-toggler navbar-light " style="background:white" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto ">
      <li class="nav-item  active" >
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="product.php">Product</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="ordered.php">order</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link "  href="about.php">about us </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="contact.php">contact us</a>
      </li>
      <li> 
      <a class="nav-link" href="logout.php">log out</a>
      </li>
      <li class="nav-item " style="position:absolute;top:30px;left:20% " >
      <marquee>
     <h6> Hello '.$_SESSION["email"].' </h6> </marquee>
      </li>
      
      
      
       
     

  </ul>
  </div>
</nav>
';
}
else{
  echo '  <nav class="navbar navbar-expand-lg  fixed-top" style="background:rgba(68, 18, 248, 200)">
  <a style="color:white;font-size:30px;line-height:1em;font-weight:900" class="navbar-brand" href="#"><img class="img img-responsive logo animate__animated animate__bounce animate__infinite infinite" height=60px width=50px src="image/OIP.jfif" alt=""> &nbsp; Onli9 Mart</a>
  <button class="navbar-toggler navbar-light" style="background:white" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto ">
      <li class="nav-item  active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="product.php">Product</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="ordered.php">order</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link "  href="about.php">about us </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="contact.php">contact us</a>
      </li>

      
     <li class="nav-item ">
        <a class="nav-link"  href="login.php">log in</a>
      </li>
      

 </ul>
  </div>
</nav>
';

}
 
?>
</header>
