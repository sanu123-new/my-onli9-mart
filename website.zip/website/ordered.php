


<!doctype html>
<html>
    <head>
<?php 

include_once("head.php");
?>
</head>
<body  >
  
<?php 
include_once("nav.php");?>
<div class="container">
<?php
 
 $con=mysqli_connect("localhost","root","mera@sqlioplkj","online mart");
  if(isset($_POST["dltbtn"])){
      $id=$_POST["dltid"];
      $email=$_SESSION["email"];
      $q="delete  from orderproduct where PI = '$id'  && uemail='$email' ";
      $qr=mysqli_query($con ,$q);
      if($qr){
        echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Your Order has been Cancelled . 
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div> ';
        
      }
      else{
        echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Error!</strong> Your Order has not been Cancelled . 
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div> ';
          
      }
  }  
  ?>
</div>

<?php
$con=mysqli_connect("localhost","root","mera@sqlioplkj","online mart");
if(!$con)
die("could not connected");

if(isset($_SESSION["email"])){
  echo '<div  style="text-align:center"><h3 class="animate__animated animate__pulse animate__ animate__infinite infinite delay-2s">Ordered Items</h3></div><div class=" container " style="position:relative;top:10px;"><div class="row">
  ';
$s="select * from orderproduct  where uemail= '".$_SESSION["email"]."' "  ;
$no=mysqli_query($con,$s);
$check=mysqli_num_rows($no)>0;
if($check){
     while($rs=mysqli_fetch_assoc($no))
    {
      ?>

<div class="col-md-12 ">
  <div class="row" style="border:1px solid black;border-radius:1.5em;">
    <div class="col-lg-8">
    <div style="text-align:justify ;margin:2% ;">  <?php  echo " <b>Product Name : </b>" .$rs["PN"];?></div>
    <div style="text-align:justify;margin:2%;">  <?php echo "<b>Net Payable Amount : </b>".$rs["PRICE"];?></div>
    <div style="text-align:justify;margin:2% ;"><?php echo "<b> Quantity :</b>" .$rs["qty"];?></div>
    
    </div>
    <div class="col-lg-4" style="text-align:center;">
    <img height="100px" width="100px" style="align-items:center;margin-top:5px" src="adminweb/product/<?php echo $rs["PIC"] ;?>" alt="">
    <form action="ordered.php" method="post">
    <input type="hidden" name="dltid" value="<?php echo $rs['PI'];?>">
    <button class="btn btn-danger" style="width:50%;margin:3%" type="submit" name="dltbtn" class="btn btn-danger" >CANCEL</button>
    
    
    </form>
    </div>
  
    
    </div>
    <br>
    </div>
    
    
    


    <?php
    
  }
  echo '
  </div></div>';
}
}
 


else{
    echo " 
    <h1 class='text-center' style='position:relative;top:150px;align-items:center' > No Record Found</h1>";
}


?>





<?php
include_once("js.php");
?>

</body>

    </html>