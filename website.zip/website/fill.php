<!doctype html>
<html>
    <head>
<?php 

include_once("head.php");
?>
</head>
<body  >
  
<?php 
include_once("nav.php");?>

<?php


$con=mysqli_connect("localhost","root","mera@sqlioplkj","online mart");
if(!$con)
die("could not connected");
if(isset($_POST["order"])){
$pi=$_POST["pid"];
$email=$_POST["email"];
$s="select * from addproduct where PI='$pi' && EMAIL='$email'  " ;
$no=mysqli_query($con,$s);


    foreach($no as $rs)
    {
        ?>
        

    <div class="container " style=" text-align:center;position:relative;top:140px;">
    <div class="row">
    <input type="hidden" name="pid" value="<?php echo $rs['PI'];?>">
    
  
    <div class="col-lg-12  card-body"  width=300px height=300px  style="text-align:center;"><img  class=" zoom" width=300px height=300px  src="adminweb/product/<?php echo $rs['PPIC'] ; ?>"alt=""></div>
    
   
  
 
  
  
  <div class="col-lg-12"   >
  <div class="row">
  <div class="col-lg-6" style="text-align:center" ><button onclick="go();"  style="margin:10px;text-align:center;width:38%;background:red;color:white;" class="btn  text-center" type="submit" > <b>CANCEL</b> 
   </button>
</div>

   <div class="col-lg-6" style="text-align:center"  >
   <form action="order.php" method="POST">
  <input type="hidden" name="pid" value="<?php echo $rs['PI']; ?>">
  <input type="hidden" name="name" value="<?php echo $rs['PN']; ?>">
  <input type="hidden" name="price" value="<?php echo $rs['PP']; ?>">
  <input type="hidden" name="pic" value="<?php echo $rs['PPIC']; ?>">
  <input type="hidden" name="email" value="<?php echo $rs['EMAIL']; ?>">
  
   <button  style="text-align:center;width:39%;margin:10px;background:rgba(68, 18, 248, 200);color:white;" class="btn  text-center" type="submit" name="po" ><b>CONFIRM ORDER</b> </button>
   </form>
   </div>
</div>
</div>
  
    </div>


    </div>
    
    </div>






<?php
    }  
}
    else{
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>sorry!</strong> You are not logged in
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div> ';
    }



?>

<script src="1.js"></script>
<?php
include_once("js.php");
?>

</body>

    </html>