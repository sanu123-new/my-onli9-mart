<?php
$con=mysqli_connect("localhost","root","mera@sqlioplkj","online mart");
if(!$con)
  die("404 NOT FOUND ");
$showAlert = false;
$showError = false;
if($_SERVER["REQUEST_METHOD"] == "POST"){
    

    $username = $_POST["name"];
    $email=$_POST["email"];
    $password = $_POST["pwd"];
    $cpassword = $_POST["cpwd"];
    // $exists=false;

    // Check whether this username exists
    $existSql = "SELECT * FROM signin WHERE EMAIL = '".$email."'";
    $result = mysqli_query($con, $existSql);
    $numExistRows = mysqli_num_rows($result);
    if($numExistRows > 0){
        // $exists = true;
        $showError = "This Email id Already Exists ! please log in";
    }
    else{
        // $exists = false; 
        if(($password == $cpassword)){
            $hash = password_hash($password,PASSWORD_DEFAULT);
            $sql = "INSERT INTO signin VALUES ('".$username."','".$email."','".$hash."',current_timestamp())";
            $result = mysqli_query($con, $sql);
            if ($result){
                $showAlert = true;
            }
        }
        else{
            $showError = "password do not match";
        }
    }
}
    
?>



    
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<?php include_once("head.php");?>
</head>
<body class="signin">
<?php include_once("nav.php") ; ?>
<section id="sign" style="position:relative;top:20px;margin-bottom:50px;">
<div class="container" >
<?php
    if($showAlert){
    echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Your account is now created and you can login <a href="login.php">Click Here To Log In</a>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div> ';
    }
    if($showError){
    echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error!</strong> '.$showError.' 
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div> ';
    }
    ?>


</div>

<div class="container text-center     "style="position:relative;top:15%;margin-bottom:50px;"> 

<form  action="<?php $_PHP_SELF ?>  " method="post">


<div class="col-lg-12">
<h2 style="color:rgba(68, 18, 248, 200);font-weight:900" >Sign IN TO Onli9 Mart </h2>

</div>
<div >
<input required maxlength="15" style="width:400px;height:50px;margin:1.5%;background:none;text-align:center;border-style:none none solid none;color:purple;" type="text" placeholder="Enter Full Name" name="name">
</div>
<div >
<input required style="width:400px;height:50px;margin:1.5%;color:purple;text-align:center;background:none;border-style:none none solid none;" type="email" placeholder="Enter Email" name="email">
</div>
<div >
<input required minlength="6"  maxlength="15" style="width:400px;height:50px;margin:1.5%;text-align:center;background:none;border-style:none none solid none;color:purple;" type="password" placeholder="Enter  Password" name="pwd">
</div>
<div>
<input required  minlength="6"  maxlength="15" style="width:400px;height:50px;margin:1.5%;text-align:center;border-style:none none solid none;background:none;color:purple" type="password" placeholder="Re-Enter  Password" name="cpwd">
</div>
<div >

<input class="btn " style="background:rgba(68, 18, 248, 200);width:400px;height:50px;margin:2% 0%;border-radius:1.5rem;border-style:none none solid none;border-style:none none solid none;border:1px solid white;color:white;font-weight:900" type="submit" name="sign " value="SIGN IN">
</div>

<div  style="text-align:center">
<a style="text-decoration:none ;color:rgba(68, 18, 248, 200)" href="login.php"><h6>log in if already a member</h6></a>
</div>

</form>
</div>





</section>


<?php include_once("js.php");?> 
</body>
</html>