<html>
    <head>
    <?php include_once("head.php"); ?>
    </head>


    <body>
    <?php include_once("nav.php"); ?>

    
     
     <?php


$con=mysqli_connect("localhost","root","mera@sqlioplkj","online mart");
if(!$con)
die("could not connected");
$s="select * from addproduct  " ;
$no=mysqli_query($con,$s);
$check=mysqli_num_rows($no)>0;

if($check){
 
  echo 

'  

<div class="container-fluid" style="margin:0% 1%;position:relative;top:1px;">
  <div class="alert  alert-dismissible fade show" role="alert" >

  <div id="carouselExampleControls" class="carousel slide carousel-fade" data-ride="true" style="height:200px;width:100%; border-radius:60%">
  <div class="carousel-inner">
    <div class="carousel-item active "data-interval="1000">
      <img width=100px height=200px src="image/c1.jpg" class="d-block h-100 w-100" alt="...">
    </div>
    <div class="carousel-item "data-interval="3000">
      <img width=100px height=200px src="image/c2.jpg" class="d-block w-100" alt="...">
    </div>
    
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>

</div>
</div>

    </div>
  <div class="container-fluid" style="position:relative;top:10px;margin:auto;">

  
 
      
  <div class="row" >';
    while($rs=mysqli_fetch_assoc($no) )
    {
     ?>
      
      <div class="col-md-3 card" style="margin:15px 60px;text-align:center ;border-radius:1.5em;background:radial-gradient(red,blue)">
      <div class="card-title animate__animated animate__pulse animate__ animate__infinite infinite delay-2s" style="background:green;border-radius:1.5em;color:white;width:150px;margin-top:5px;padding:2px"><?php echo"Discount  ".$rs["DISCOUNT"]."%"; ?></div>
      <form action="purchase.php" method="POST"enctype="multipart/form-data" >  <p class="card-body"> <input type="hidden" name="email" value="<?php echo $rs['EMAIL']; ?>"><input type="hidden" name="pid" value="<?php echo $rs['PI']; ?>"><button name="purchase" type="submit" style="border:none ;width:100%;background:none;"> <img class="card-img-top" style="background:#dcdce1" width=200 height=200 src="adminweb/product/<?php echo $rs['PPIC'] ; ?>" alt=""></button> </p>
    </form >
  <p class="card-title" style="text-tarnsform:capitalize;color:white"><?php echo "<b>". $rs["PN"]. "</b>"; ?></p>
  <p class="card-text animate__animated animate__pulse animate__ animate__infinite infinite delay-2s" style="color:white"><?php echo " <b> Rs ".$rs["PP"]."/Only</b>"; ?></p>
  <p class="card-text " style="color:white" ><?php echo " Before Today Rs<strike>".$rs["MP"]."/</strike>"; ?></p>
  
  <form action="fill.php" method="POST">
  <input type="hidden" name="pid" value="<?php echo $rs['PI']; ?>">
  <input type="hidden" name="email" value="<?php echo $rs['EMAIL']; ?>">
  
  <button  style="text-align:center;height:100%;width:100%;background:rgba(68, 18, 248, 200);color:white" class="btn  text-center" type="submit" name="order" > <b>BUY NOW</b>  </button><br>
  </form>

  
    
  </div>
   

  


<?php   
    }
   echo  ' </div></div>
   
   
   ';
}
else{
    echo " 
    <h1 class='text-center' > No Record Found</h1>";
}
?>




 









    <?php include_once("js.php"); ?>
    </body>

</html>
