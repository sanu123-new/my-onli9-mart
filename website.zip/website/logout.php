<html>
<head>
<?php include_once("head.php"); ?>
</head>

<body>
<?php include_once("nav.php"); ?>
<?php
if(isset($_POST["logout"])){
    session_start();
    session_destroy();
    session_unset();
    header("location:login.php");
}
?>

<div class="container" style="position:relative;top:10%">


<div class="alert  alert-dismissible fade show" role="alert" style="color:green;text-align:center;">

<h5 style="text-transform:uppercase">

<?php 
 $con=mysqli_connect("localhost","root","mera@sqlioplkj","online mart");
 if(!$con)
   die("404 NOT FOUND ");

if(isset($_SESSION["email"])){
    $sql = "Select * from signin where EMAIL ='".$_SESSION["email"]."'";
    $result = mysqli_query($con, $sql);
    $num = mysqli_num_rows($result);
    if ($num == 1){
        while($row=mysqli_fetch_assoc($result)){
            echo  ' '.$row["NAME"].' ';
        }

    }
}

?>
, Think Before Logging Out .
</h5>
 
</div>




<form action="logout.php" method="post">
<div class="alert  alert-dismissible fade show" role="alert" style="color:green;text-align:center;">
<input style="text-align:center" type="checkbox" required > &nbsp; Do you really want to logout ?
<br><br>
<button style="width:250px;font-weight:900" class="btn btn-danger" name="logout" type="submit">LOG OUT</button>
</div>

</form>

</div>

<?php include_once("js.php"); ?>
</body>
</html>


