<!DOCTYPE html>
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<?php include_once("head.php");?>

</head>
<body class="con"  >
<?php include_once("nav.php") ; ?>


<?php 

$con=mysqli_connect("localhost","root","mera@sqlioplkj","online mart");
if(!$con)
  die("404 NOT FOUND ");
  $showAlert=false;
  $showError=false;



if($_SERVER["REQUEST_METHOD"] == "POST"){
  
  $name=$_POST["name"];
  $email=$_POST["email"];
  $message=$_POST["message"];
  $sql="insert into query VALUES('".$name."','".$email."','".$message. "',current_timestamp())";
  $query=mysqli_query($con,$sql);
 if($query!=0){
   $showAlert=true;
}
 else{
  $showerror ="We fetching some network issue ! Try after a while";
 }
 
  
}

?>


<div class="page-wrapper" >
<form action="<?php $_PHP_SELF ?>" method ="POST">

<div class="container contact" style="position:relative;top:10px;margin-bottom:50px;">


<div class="row">
<div class="col-lg-12">

<?php
if($showAlert){
  echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
      <strong>Thnak You For Contacting Us!</strong> our team will shortly get in touch with you
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
      </button>
  </div> ';
  }
  if($showError){
  echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <strong>Error!</strong> '.$showError.' 
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
      </button>
  </div> ';
  }
?>

</div>
<br>


<div class="col-lg-12"><h3 class="text-center " style="color:rgba(68, 18, 248, 200);align-items:center">Contact Form</h3></div>



  <div class="form-group col-lg-12 " >
    
    <input type="text" name="name" placeholder="Enter Your Name" required class="form-control " aria-describedby="emailHelp" style="background:none;border-style:none none solid none ;color:green;border-radius:0%;margin:1%">
   
  </div>
  <div class="form-group col-lg-12">
    
    <input type="email" name="email" required placeholder="Enter Your Email"  class="form-control "style="background:none;border-style:none none solid none ;color:green;border-radius:0%;margin:1%" >
  </div>
  <div class="form-group col-lg-12">
   
   <textarea required name="message" placeholder="write your problem within 200 words only"  class="form-control "  name="" id="" cols="20" rows="10"style="background:none;border-style:solid ;color:green;border-radius:0% ;margin:1%"></textarea>
  </div>
  
  <div class="col-lg-12" ><input style="font-size:20px;width:100%;font-weight:900" type="submit" name="csub" onclick="contact" value="Submit" class="btn btn-success " style="width:100%"></div>


</div>
</div>





</form>

</div>




<?php include_once("js.php");?> 
</body>

</html>

