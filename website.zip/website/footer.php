<div class="container-fluid" >
<div class="row  "  >
  <div class="col-lg-12 col-sm-12 col-lg-12 " align="center" style="align-items:center;padding:2%" >
<div class="row">
<div class="col-lg-4 col-sm-4 col-lg-4 ">
    <div><h5>ABOUT</h5></div> 
    
<table cellpadding=10 align="center">
  
  <tr>
    <td><i style="font-size:20px" class="fas fa-phone-volume"> PHONE </i></td><td>97986809898</td>

  </tr>
  <tr>
    <td><i style="font-size:20px" class="fas fa-envelope-open"> EMAIL </i></td>
    <td>info@gmail.com</td>
  </tr>
  <tr>
    <td> <i style="font-size:20px" class="far fa-address-book"> ADDRESS  </i></td> 
    <td>DELHI NCR ,SEC-15 </td>
  </tr>
</table>
    
</div>
<div class="col-lg-4 col-sm-4 col-lg-4 ">
<div><h5>Important Links</h5></div> 
    
    <table cellpadding=10 align="center">
      <tr>
        <td> <a style="text-decoration:none;color:black" href=""><i style="font-size:20px" class="fab fa-facebook"> Facebook </i></a> </td>
        
      </tr>
      <tr>
        <td> <a style="text-decoration:none;color:black" href=""><i style="font-size:20px" class="fab fa-twitter"> TWITTER </i></a></td>
    
      </tr>
      <tr>
        <td><a style="text-decoration:none;color:black" href=""><i style="font-size:20px" class="fab fa-instagram-square"> INSTAGRAM</i></a></td>
       
      </tr>
    </table>
</div>
<div class="col-lg-4 col-sm-4 col-lg-4 ">
<div><h5>Ratings Achieved</h5></div> 
    
    <table cellpadding=10 align="center">
    <tr>
        <td> boat</td> <td><i class="fas fa-star"></i><i class="fas fa-star">
        </i><i class="fas fa-star">
        </i>
        <i class="fas fa-star-half-alt"></i></td>
        </tr>
        <tr>
        <td> Puma</td> <td><i class="fas fa-star"></i><i class="fas fa-star">
        </i><i class="fas fa-star">
        </i><i class="fas fa-star"></i>
        </td>
      
      </tr>
      <tr>
        <td> Amazon </td> <td><i class="fas fa-star"></i><i class="fas fa-star">
        </i><i class="fas fa-star">
        </i><i class="fas fa-star"></i>
        <i class="fas fa-star-half-alt"></i></td>
        <tr>
        <td> Flipkart</td> <td><i class="fas fa-star"></i><i class="fas fa-star">
        </i><i class="fas fa-star">
        </i><i class="fas fa-star"></i>
        <i class="fas fa-star"></i></td>
        
      
    </table>
</div>
</div>
  </div>

  <div style=";text-align:center;align-items:center;padding:1%" class="col-lg-12 col-md-12 col-lg-xs">&copy; COPYRIGHT 2020 ALL RIGHTS RESERVED | CREATOR HIMANSHU KUMAR</div>
</div>

</div>
 <div class="row  "  >
  <div class="col-lg-12 col-sm-12 col-lg-12 " align="center" style="align-items:center;padding:2%" >
<div class="row">
<div class="col-lg-4 col-sm-4 col-lg-4 ">
    <div><h5>ABOUT</h5></div> 
    
<table cellpadding=10 align="center">
  
  <tr>
    <td><i style="font-size:20px" class="fas fa-phone-volume"> PHONE </i></td><td>97986809898</td>

  </tr>
  <tr>
    <td><i style="font-size:20px" class="fas fa-envelope-open"> EMAIL </i></td>
    <td>info@gmail.com</td>
  </tr>
  <tr>
    <td> <i style="font-size:20px" class="far fa-address-book"> ADDRESS  </i></td> 
    <td>DELHI NCR ,SEC-15 </td>
  </tr>
</table>
    
</div>
<div class="col-lg-4 col-sm-4 col-lg-4 ">
<div><h5>Important Links</h5></div> 
    
    <table cellpadding=10 align="center">
      <tr>
        <td> <a style="text-decoration:none;color:black" href=""><i style="font-size:20px" class="fab fa-facebook"> Facebook </i></a> </td>
        
      </tr>
      <tr>
        <td> <a style="text-decoration:none;color:black" href=""><i style="font-size:20px" class="fab fa-twitter"> TWITTER </i></a></td>
    
      </tr>
      <tr>
        <td><a style="text-decoration:none;color:black" href=""><i style="font-size:20px" class="fab fa-instagram-square"> INSTAGRAM</i></a></td>
       
      </tr>
    </table>
</div>
<div class="col-lg-4 col-sm-4 col-lg-4 ">
<div><h5>Ratings Achieved</h5></div> 
    
    <table cellpadding=10 align="center">
    <tr>
        <td> boat</td> <td><i class="fas fa-star"></i><i class="fas fa-star">
        </i><i class="fas fa-star">
        </i>
        <i class="fas fa-star-half-alt"></i></td>
        </tr>
        <tr>
        <td> Puma</td> <td><i class="fas fa-star"></i><i class="fas fa-star">
        </i><i class="fas fa-star">
        </i><i class="fas fa-star"></i>
        </td>
      
      </tr>
      <tr>
        <td> Amazon </td> <td><i class="fas fa-star"></i><i class="fas fa-star">
        </i><i class="fas fa-star">
        </i><i class="fas fa-star"></i>
        <i class="fas fa-star-half-alt"></i></td>
        <tr>
        <td> Flipkart</td> <td><i class="fas fa-star"></i><i class="fas fa-star">
        </i><i class="fas fa-star">
        </i><i class="fas fa-star"></i>
        <i class="fas fa-star"></i></td>
        
      
    </table>
</div>
</div>
  </div>

  <div style=";text-align:center;align-items:center;padding:1%" class="col-lg-12 col-md-12 col-lg-xs">&copy; COPYRIGHT 2020 ALL RIGHTS RESERVED | CREATOR HIMANSHU KUMAR</div>
</div>

</div>
</div>