function go(){
    window.location="product.php";
}