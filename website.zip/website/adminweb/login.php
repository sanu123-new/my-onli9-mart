<?php
$con=mysqli_connect("localhost","root","mera@sqlioplkj","online mart");
if(!$con)
  die("404 NOT FOUND ");
$login = false;
$showError = false;
if($_SERVER["REQUEST_METHOD"] == "POST"){
    
    $email = $_POST["loginemail"];
    $password = $_POST["loginpwd"]; 
    
     
    // $sql = "Select * from users where username='$username' AND password='$password'";
    $sql = "Select * from martadminsignin where EMAIL ='$email'";
    $result = mysqli_query($con, $sql);
    $num = mysqli_num_rows($result);
    if ($num == 1){
        while($row=mysqli_fetch_assoc($result)){
            if (password_verify($password, $row['PASSWORD'])){ 
            $res="insert into adminlogin values('".$email."','".$row["NAME"]."',current_timestamp())";
            $query=mysqli_query($con,$res);
                $login = true;
                session_start();
                $_SESSION['loggedin'] = true;
                $_SESSION['email'] = $email;
                header("location:index.php");
                
               
               
                
               
            } 
            else{
                $showError = "Invalid Credentials";
            }
        }
        
    } 
    else{
        $showError = "Invalid ";
    }
}
    
?>


    

  

<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<?php include_once("head.php");?>
</head>
<body class="login">
<?php include_once("nav.php") ; ?>
<div class="container">

<?php
    if($login){
    echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> You are logged in
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div> ';
    }
    if($showError){
    echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error!</strong> '. $showError.'
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div> ';
    }
    ?>

</div>

<form action="<?php $_PHP_SELF ?>" method="POST">
<div class="container text-center   " style="position:relative;top:20px;margin-bottom:50px;">
<div class="row">
<div class="col-lg-12">
<h2 style="color:black;font-weight:900" >LOG IN TO Onli9 Mart  Admin Pannel</h2>

</div>
<div class="col-lg-12 ">
<input style="width:500px;height:50px;margin:2%;text-align:center;border-style:none none solid none;background:none;" type="email" placeholder="Enter Registered Email" name="loginemail">
</div>
<div class="col-lg-12 ">
<input style="width:500px;height:50px;margin:2%;text-align:center;border-style:none none solid none;background:none;" type="password" placeholder="Enter Registered Password" name="loginpwd">
</div>
<div class="col-lg-12 ">

<input class="btn btn-primary" style="width:500px;height:50px;margin:2%;border-radius:1.5rem;border-style:none" type="submit" value="LOG IN">
</div>

<div class="col-lg-12" style="text-align:center">
<a style="text-decoration:none;color:blue" href="signin.php"><h6>Create a new account For New User</h6></a>
</div>
</div>
</div>

</form>


<?php include_once("js.php");?> 
</body>
</html>