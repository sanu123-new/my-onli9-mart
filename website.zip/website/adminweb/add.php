<?php
$showAlert = false;
$showError = false;

$con=mysqli_connect("localhost","root","mera@sqlioplkj","online mart");
if(!$con)
die("could not connected");
if($_SERVER["REQUEST_METHOD"] == "POST"){
$n1=$_POST["PI"];
  $n2=$_POST["PN"];
  $n3=$_POST["PP"];
  $n4=$_POST["MP"];
  $n7=$_POST["DP"];
  $n6=$_POST["EMAIL"];
  $n5=$_FILES["file"]["name"];
$existSql = "SELECT * FROM addproduct WHERE PI='".$n1."' && EMAIL='".$n6."'";
$result = mysqli_query($con, $existSql);
$numExistRows = mysqli_num_rows($result);
if($numExistRows > 0){
    // $exists = true;
    $showError = "This  id Already Exists ! please choose other";
}
 else{
   
  
 
  $s="insert into addproduct  values('".$n6."','".$n1."','".$n2."','".$n3."','".$n4."','".$n5."','".$n7."',current_timestamp())";
  if(move_uploaded_file($_FILES["file"]["tmp_name"],"product/".$n5)){
  $no=mysqli_query($con,$s);
  if($no!=0){
    
  $showAlert = true;
  
  }
    else 
    $showError = "did not add..";
  }

  
  
 }
 }




    




?>

<html>
<head>
<?php include_once("head.php"); ?>
</head>
<body>
<?php include_once("nav.php"); ?>

<div class="container">
<?php
    if($showAlert){
    echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Your Item Is Added . 
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div> ';
    }
    if($showError){
    echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error!</strong> '.$showError.' 
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div> ';
    }
    ?>

</div>



</div>

<div class="container">
<form action="<?php $_PHP_SELF ?>" method="post" enctype="multipart/form-data">
<div class="form-group">
    <h3 style="text-align:center;color:black">Add Item</h3>
    
  </div>
  <div class="form-group">
    
    <input readonly style="display:none;" type="text" name="EMAIL" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo ''.$_SESSION["email"].'';?>">
    
  </div>

  <div class="form-group">
    <label for="exampleInputEmail1">Product Id</label>
    <input required type="text" name="PI" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder=" Enter Produt Id">
    
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Product Name</label>
    <input required  type="text" name="PN" class="form-control" id="exampleInputPassword1" placeholder=" Enter Product Name">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Product Price</label>
    <input required  type="text" name="PP" class="form-control" id="exampleInputPassword1" placeholder=" Enter Product Price">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Marginal Price</label>
    <input required  type="text" name="MP" class="form-control" id="exampleInputPassword1" placeholder=" Enter Marginal Price">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Discount Price</label>
    <input required  type="text" name="DP" class="form-control" id="exampleInputPassword1" placeholder=" Enter DISCOUNT">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Product Picture</label>
    <input required  type="file" name="file" class="form-control" id="exampleInputPassword1">
  </div>
  <button type="submit" name="submit" class="btn btn-primary ">ADD ITEM</button>
</form>








</div>


    

<?php include_once("js.php"); ?>
</body>
</html>