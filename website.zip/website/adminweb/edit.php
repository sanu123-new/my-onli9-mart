

<html>
<head>
<?php include_once("head.php") ;?>
</head>
<body>
<div class="container">
<?php include_once("nav.php") ;?>

    
<?php
$con=mysqli_connect("localhost","root","mera@sqlioplkj","online mart");

if(isset($_POST["editbtn"])){
    $id=$_POST["editid"];
    $email=$_SESSION["email"];
    $q="select * from addproduct where PI = '$id' && EMAIL='$email' ";
    
   
   
    $qr=mysqli_query($con ,$q);
    foreach($qr as $row)
    {
?>

 


<form action="history.php" method="POST" >
<div class="form-group">
    <h3 style="text-align:center;color:black">UPDATE ITEM</h3>
    
  </div>
  <input type="hidden" name="editid" value="<?php echo $row['PI'];?>">

  
  <div class="form-group">
    <label for="exampleInputPassword1">Product Name</label>
    <input required  type="text" name="CPN" class="form-control" id="exampleInputPassword1" value="<?php echo $row['PN'];?>">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Product Price</label>
    <input required  type="text" name="CPP" class="form-control" id="exampleInputPassword1" value="<?php echo $row['PP'];?>">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Marginal Price</label>
    <input required  type="text" name="CMP" class="form-control" id="exampleInputPassword1" value="<?php echo $row['MP'];?>">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Discount Price</label>
    <input required  type="text" name="CDP" class="form-control" id="exampleInputPassword1" value="<?php echo $row['DISCOUNT'];?>">
  </div>
  
  <button type="submit" name="edited" class="btn btn-primary ">UPDATE</button>
</form>
   


<?php

    }
  
   
}


?>

 </div>



<?php include_once("js.php") ;?>
</body>
</html>
