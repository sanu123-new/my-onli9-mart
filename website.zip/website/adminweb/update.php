<html>
<head>
<?php include_once("head.php")?>

</head>
<body>
<?php include_once("nav.php")?> 

    <?php
    
   
$con=mysqli_connect("localhost","root","mera@sqlioplkj","online mart");
if(isset($_POST["edited"])){
    $id=$_POST["editid"];
    $email=$_SESSION["email"];
    $name=$_POST["CPN"];
    $price=$_POST["CPP"];
    $mprice=$_POST["CMP"];
    $dprice=$_POST["CDP"];
 
    $s="update addproduct set PN='$name',PP='$price',MP='$mprice' DISCOUNT='$dprice'   where PI='$id' && EMAIL='$email' ";
  
  $no=mysqli_query($con,$s);
  
  if($no!=0){
    
    echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>Success!</strong> Your Item Is Added . 
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div> ';
 
  

  
  }
    else 
    echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Error!</strong> '.$showError.' 
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div> ';
  }

  

   
 
      ?>
      

      <?php include_once("js.php")?> 
      </body>
</html>