<html>
<head>
<?php include_once("head.php") ; ?>

</head>
<body>
<?php include_once("nav.php") ; ?> 
<div class="container">
<?php
    
   
    $con=mysqli_connect("localhost","root","mera@sqlioplkj","online mart");
    if(isset($_POST["edited"])){
        $id=$_POST["editid"];
        $email=$_SESSION["email"];
        $name=$_POST["CPN"];
        $price=$_POST["CPP"];
        $mprice=$_POST["CMP"];
        $dprice=$_POST["CDP"];
     
        $s="update addproduct set PN='$name',PP='$price',MP='$mprice', DISCOUNT=' $dprice'   where PI='$id' && EMAIL='$email' ";
      
      $no=mysqli_query($con,$s);
      
      if($no!=0){
        
        echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Your Details has been updated to website . 
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div> ';
     
      
    
      
      }
        else 
        echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error!</strong> We fetching some issue while updating . Try After Some Time
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div> ';
      }
    
      
    
       
     
          ?>
          

<?php
 
 $con=mysqli_connect("localhost","root","mera@sqlioplkj","online mart");
  if(isset($_POST["dltbtn"])){
      $id=$_POST["dltid"];
      $email=$_SESSION["email"];
      $q="delete  from addproduct where PI = '$id'  && EMAIL='$email' ";
      $qr=mysqli_query($con ,$q);
      if($qr){
        echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Your Details has been deleted . 
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div> ';
        
      }
      else{
        echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Error!</strong> Your Details has not been deleted . 
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div> ';
          
      }
  }  
  ?> 
  

</div>

<?php
$con=mysqli_connect("localhost","root","mera@sqlioplkj","online mart");
if(!$con)
die("could not connected");

if(isset($_SESSION["email"])){
  echo '<div class=" container table-responsive"><ol type="1" style="list-style-position:inside">
<table  style="text-align:center"  class="table  " >  <tr>
  <th>Sl No.</th><th>Product Id</th><th>Product Name</th><th>Product Price</th><th>Product Image</th><th>Edit</th><th>Delete</th>';
$s="select * from addproduct  where EMAIL= '".$_SESSION["email"]."' "  ;
$no=mysqli_query($con,$s);
$check=mysqli_num_rows($no)>0;
if($check){
     while($rs=mysqli_fetch_assoc($no))
    {
      ?>
    
    
    <tr>
    
    <td>
    
    <li></li>

    </td>
    
    <td>    <?php echo $rs["PI"];?></td>
    
   <td>    <?php echo $rs["PN"];?></td>
    <td>    <?php echo $rs["PP"];?></td>
    <td> <img  height=100 width=200 src="product/<?php echo $rs['PPIC'];?>" alt="">   </td>
    <td>
    <form action="edit.php" method="post">
    
    <input type="hidden" name="editid" value="<?php echo $rs['PI'];?>">
    <button type="submit" class="btn btn-success" name="editbtn">EDIT</button>
    </form>
    </td>
    <td>
    <form action="history.php" method="post">
    <input type="hidden" name="dltid" value="<?php echo $rs['PI'];?>">
    <button type="submit" name="dltbtn" class="btn btn-danger" >DELETE</button>
    
    
    </form>
    
    </td>

    </tr>
    
    



    <?php
    
  }
  echo '</ol> </tr> </table></div>';
}
}
 


else{
    echo " 
    <h1 class='text-center' style='position:relative;top:150px;align-items:center' > No Record Found</h1>";
}


?>

<?php include_once("js.php");?>

</body>
</html>