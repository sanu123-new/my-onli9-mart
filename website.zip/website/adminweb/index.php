<html>
<head>
<?php include_once("head.php");?>
</head>
<body>
<?php include_once("nav.php");?> 
<?php  
$con=mysqli_connect("localhost","root","mera@sqlioplkj","online mart");
if(!$con)
  die("404 NOT FOUND ");

if(isset($_SESSION["email"])){
   $sql = "Select * from martadminsignin where EMAIL ='".$_SESSION["email"]."'";
   $result = mysqli_query($con, $sql);
   $num = mysqli_num_rows($result);
   if ($num == 1){
       while($row=mysqli_fetch_assoc($result)){
        echo '<div class="container">
        <div class="alert " role="alert" style="background:linear-gradient(blue,red);color:white">
          <h4 class="alert-heading" style="text-transform:capitalize">Welcome Dear Admin  '.$row["NAME"].'!</h4>
          <p style="text-transform:capitalize">online mart welcomes you as  an admin .sell products and earn </p>
          <hr>
          <p class="mb-0">Whenever you  need help you can contact us via registered phone number to our management system.</p>
        </div>
        <div class=" alert alert-dismissible fade show" role="alert text-center " style="background:blue;color:white;text-align:center"><a style="color:white;font-size:20px;font-weight:700;text-decoration:none" href="add.php">ADD PRODUCT</a></div>
        
        <div class=" alert alert-dismissible fade show" role="alert text-center " style="background:blue;color:white;text-align:center"><a style="color:white;font-size:20px;font-weight:700;text-decoration:none" href="history.php">YOUR UPLOADS</a></div>
        <div class=" alert alert-dismissible fade show" role="alert text-center " style="background:blue;color:white;text-align:center"><a style="color:white;font-size:20px;font-weight:700;text-decoration:none" href="history.php">UPDATE DATA</a></div>
        <div class=" alert alert-dismissible fade show" role="alert text-center " style="background:blue;color:white;text-align:center"><a style="color:white;font-size:20px;font-weight:700;text-decoration:none" href="history.php">DELETE DATA</a></div>


        <div class=" alert alert-dismissible fade show" role="alert text-center " style="background:blue;color:white;text-align:center"><a style="color:white;font-size:20px;font-weight:700;text-decoration:none" href="logout.php">LOG OUT</a></div>
        
        ';  
       }

   }
}




else{
    echo '<div class="container">
    <div class="alert alert-success alert-dismissible fade show" role="alert" style="background:linear-gradient(blue,red);color:white">
    <strong>Please!</strong> Make Sure , You are logged in <a href="login.php">click here to login </a>
    
</div>
</div>';
}

?>



<?php include_once("js.php");?>
</body>
</html>