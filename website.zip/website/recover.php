<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
        <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
  />
        <link rel="stylesheet" href="1.css">
        <script src="https://kit.fontawesome.com/7906776ae1.js" crossorigin="anonymous"></script>
</head>
    <body>
<header>
    <nav class="navbar navbar-expand-lg navbar-light fixed-top">
  <a style="font-size:30px;line-height:1em;font-weight:900" class="navbar-brand" href="#"><img class="img img-responsive logo animate__animated animate__bounce animate__infinite infinite" height=60px width=50px src="image/OIP.jfif" alt=""> &nbsp; MY MALL</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item  active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="product.php">Product</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="order.php">order</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="about.php">about us </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="contact.php">contact us</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="login.php">log in</a>
      </li>
    </ul>
  </div>
</nav>

</header>
<div id="carouselExampleCaptions" class="carousel slide" data-pause="hover" data-ride="true" data-interval="6000">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
    <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img height=400px src="image/fish.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption  d-md-block">
        <h2 class="animate__animated animate__slideInDown ite animate__delay-1s"  style="color:brown;font-weight:900" >Welcome To My Mall</h2>
        
        <p class="animate__animated animate__slideInLeft animate__delay-2s" style="color:blue;font-size:30px;font-weight:900">Your Trust
         Our Responsibility</p>
        <button class="btn btn-danger animate__animated animate__slideInLeft animate__delay-3s">Log In</button>
        <button class="btn btn-primary animate__animated animate__slideInRight animate__delay-4s"> Sign Up</button>
      </div>
    </div>
    
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>








<section class=" m1 " >


<div class="container-fluid " >
 <div class="row "style="text-align:center;padding:5%" >
      <div class="col-lg-12 ani1 ">
<h2 width=50px  style="background:linear-gradient(green,white)"  >
            Our Service
          </h2>
      </div>
 </div>
<div class="row" style="text-align:center;" >
<div class="col-lg-6" >
<img class="img img-responsive" style="border-radius:0.5rem;border:1px solid green" width=400px src="image/deliver.jpg" alt=""></div>


<div class="col-lg-6" style="align-items:center;text-align:center;padding-right:10%;padding-left:10%">
<p align="justify"> <b>Online Mart</b> Online Services Private Limited owns  and operates e-commerce website. 
         The Company provides books, movies, music, games, consoles, televisions, mobiles,  digital cameras, computers, 
         network components, software, peripherals, apparel, shoes, and kitchen appliances. 
          Online Mart Online Services serves customers in India.
  </p>
</div>
</div>
<div class="row " style="text-align:center;padding:5%">
      <div class="col-lg-12 ani1 ">
<h2  style="background:linear-gradient(green,white)"  >
            Our Delivery Partner
          </h2>
      </div>
 </div>
  <div class="row " style="text-align:center;" >
 <div class="col-lg-6" >
 <img style="margin:3%;border-radius:80%" src="image/delhi.jfif"  height=100px width="200px" alt="">
     
      
 </div>
 <div class="col-lg-6" >
 <img class=" img img-round"  style="margin:3%;border-radius:80%" src="image/ekart.jfif" height=100px width=200px  alt="">
       
      
 </div>
  </div>
   
   <div class="container-fluid  ">
 <div class="row " style="text-align:center;padding:5%">
      <div class="col-lg-12 ani1 " >
<h2 width=50px style="background:linear-gradient(green,white);"  >
            Our Associatives
          </h2>
      </div>
 </div>

 <div class="row ani2" style="margin:3%;text-align:center;" >
     <div class="col-lg-3"style="align-items:center;"><img  style="margin:3%;text-align:center;" height=100px width=150px src="image/a.jfif" alt=""></div>
     <div class="col-lg-3" style="align-items:center;"><img  style="margin:3%;text-align:center;" height=100px width=150px src="image/b.jfif" alt=""></div>
     <div class="col-lg-3" style="align-items:center;"><img  style="margin:3%;text-align:center;" height=100px width=150px src="image/f.jfif" alt=""></div>
     <div class="col-lg-3" style="align-items:center;"><img  style="margin:3%;text-align:center;" height=100px width=150px src="image/p.jfif" alt=""></div>
 </div>
   </div>

<div class="row ">
  <div class="col-lg-12 col-sm-12 col-lg-12 " align="center" style="background:linear-gradient(green,white);align-items:center;padding:2%" >
<div class="row">
<div class="col-lg-4 col-sm-4 col-lg-4 ">
    <div><h5>ABOUT</h5></div> 
    
<table cellpadding=10 align="center">
  
  <tr>
    <td><i style="font-size:20px" class="fas fa-phone-volume"> PHONE </i></td><td>97986809898</td>

  </tr>
  <tr>
    <td><i style="font-size:20px" class="fas fa-envelope-open"> EMAIL </i></td>
    <td>info@gmail.com</td>
  </tr>
  <tr>
    <td> <i style="font-size:20px" class="far fa-address-book"> ADDRESS  </i></td> 
    <td>DELHI NCR ,SEC-15 </td>
  </tr>
</table>
    
</div>
<div class="col-lg-4 col-sm-4 col-lg-4 ">
<div><h5>Important Links</h5></div> 
    
    <table cellpadding=10 align="center">
      <tr>
        <td> <a style="text-decoration:none;color:black" href=""><i style="font-size:20px" class="fab fa-facebook"> Facebook </i></a> </td>
        
      </tr>
      <tr>
        <td> <a style="text-decoration:none;color:black" href=""><i style="font-size:20px" class="fab fa-twitter"> TWITTER </i></a></td>
    
      </tr>
      <tr>
        <td><a style="text-decoration:none;color:black" href=""><i style="font-size:20px" class="fab fa-instagram-square"> INSTAGRAM</i></a></td>
       
      </tr>
    </table>
</div>
<div class="col-lg-4 col-sm-4 col-lg-4 ">
<div><h5>Ratings Achieved</h5></div> 
    
    <table cellpadding=10 align="center">
    <tr>
        <td> boat</td> <td><i class="fas fa-star"></i><i class="fas fa-star">
        </i><i class="fas fa-star">
        </i>
        <i class="fas fa-star-half-alt"></i></td>
        </tr>
        <tr>
        <td> Puma</td> <td><i class="fas fa-star"></i><i class="fas fa-star">
        </i><i class="fas fa-star">
        </i><i class="fas fa-star"></i>
        </td>
      
      </tr>
      <tr>
        <td> Amazon </td> <td><i class="fas fa-star"></i><i class="fas fa-star">
        </i><i class="fas fa-star">
        </i><i class="fas fa-star"></i>
        <i class="fas fa-star-half-alt"></i></td>
        <tr>
        <td> Flipkart</td> <td><i class="fas fa-star"></i><i class="fas fa-star">
        </i><i class="fas fa-star">
        </i><i class="fas fa-star"></i>
        <i class="fas fa-star"></i></td>
        
      
    </table>
</div>
</div>
  </div>

  <div style="background:linear-gradient(green,white);text-align:center;align-items:center;padding:1%" class="col-lg-12 col-md-12 col-lg-xs">&copy; COPYRIGHT 2020 ALL RIGHTS RESERVED | CREATOR HIMANSHU KUMAR</div>
</div>

</div>
</div>
   
 </section>
 


   







 





 



    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    </body>
    </html>