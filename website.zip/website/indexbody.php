<section class=" m1 ">


<div class="container-fluid " style="background:radial-gradient(red,blue)" >
 <div class="row "style="text-align:center;padding:5%" >
      <div class="col-lg-12 ani1 ">
<h2 width=50px  style="color:white"  >
            Our Service
          </h2>
      </div>
 </div>
<div class="row" style="text-align:center;" >
<div class="col-lg-6" >
<img class="img img-responsive" style="border-radius:0.5rem;border:1px solid white" width=400px src="image/deliver.jpg" alt=""></div>


<div class="col-lg-6" style="align-items:center;text-align:center;padding-right:10%;padding-left:10%;color:white">
<p align="justify"> <b>Online Mart</b> Online Services Private Limited owns  and operates e-commerce website. 
         The Company provides books, movies, music, games, consoles, televisions, mobiles,  digital cameras, computers, 
         network components, software, peripherals, apparel, shoes, and kitchen appliances. 
          Online Mart Online Services serves customers in India.
  </p>
</div>
</div>
<div class="row " style="text-align:center;padding:5%">
      <div class="col-lg-12 ani1 ">
<h2  style="color:white" >
            Our Delivery Partner
          </h2>
      </div>
 </div>
  <div class="row " style="text-align:center;" >
 <div class="col-lg-4 " >
 <img style="margin: 3%;border-radius:80%" src="image/delhi.jfif"  height=100px width="200px" alt="">
     
      
 </div>
 <div class="col-lg-4" >
 <img class=" img img-round"  style="margin: 3%;border-radius:80%" src="image/bluedart.jpg" height=100px width=200px  alt="">
       
      
 </div>
 <div class="col-lg-4" >
 <img class=" img img-round"  style="margin:3%;border-radius:80%" src="image/ekart.jfif" height=100px width=200px  alt="">
       
      
 </div>
  </div>
   
   <div class="container-fluid  ">
 <div class="row " style="text-align:center;padding:5%">
      <div class="col-lg-12 ani1 " >
<h2 width=50px  style="color:white" >
            Our Associatives
          </h2>
      </div>
 </div>

 <div class="row ani2" style="padding-bottom:5%;text-align:center;" >
     <div class="col-lg-3"style="align-items:center;"><img  style="margin:   3% ;text-align:center;" height=100px width=150px src="image/a.jfif" alt=""></div>
     <div class="col-lg-3" style="align-items:center;"><img  style="margin:3%;text-align:center;" height=100px width=150px src="image/b.jfif" alt=""></div>
     <div class="col-lg-3" style="align-items:center;"><img  style="margin: 3%;text-align:center;" height=100px width=150px src="image/f.jfif" alt=""></div>
     <div class="col-lg-3" style="align-items:center;"><img  style="margin:3%;text-align:center;" height=100px width=150px src="image/p.jfif" alt=""></div>
 </div>
   </div>

   <div class="row  " style="background: linear-gradient(white,blue)" >
  <div class="col-lg-12 col-sm-12 col-lg-12 " align="center" style="align-items:center;padding:2%" >
<div class="row">
<div class="col-lg-4 col-sm-4 col-lg-4 ">
    <div><h3  style="color:brown">ABOUT</h3></div> 
    
<table cellpadding=10 align="center">
  
  <tr>
    <td><i style="font-size:20px" class="fas fa-phone-volume"> PHONE </i></td><td>97986809898</td>

  </tr>
  <tr>
    <td><i style="font-size:20px" class="fas fa-envelope-open"> EMAIL </i></td>
    <td>info@gmail.com</td>
  </tr>
  <tr>
    <td> <i style="font-size:20px" class="far fa-address-book"> ADDRESS  </i></td> 
    <td>DELHI NCR ,SEC-15 </td>
  </tr>
</table>
    
</div>
<div class="col-lg-4 col-sm-4 col-lg-4 ">
<div><h3  style="color:brown">Important Links</h3></div> 
    
    <table cellpadding=10 align="center">
      <tr>
        <td> <a style="text-decoration:none;color:black" href=""><i style="font-size:20px" class="fab fa-facebook"> Facebook </i></a> </td>
        
      </tr>
      <tr>
        <td> <a style="text-decoration:none;color:black" href=""><i style="font-size:20px" class="fab fa-twitter"> TWITTER </i></a></td>
    
      </tr>
      <tr>
        <td><a style="text-decoration:none;color:black" href=""><i style="font-size:20px" class="fab fa-instagram-square"> INSTAGRAM</i></a></td>
       
      </tr>
    </table>
</div>
<div class="col-lg-4 col-sm-4 col-lg-4 ">
<div><h3 style="color:brown">Ratings Achieved</h3></div> 
    
    <table cellpadding=10 align="center">
    <tr>
        <td> boat</td> <td><i class="fas fa-star"></i><i class="fas fa-star">
        </i><i class="fas fa-star">
        </i>
        <i class="fas fa-star-half-alt"></i></td>
        </tr>
        <tr>
        <td> Puma</td> <td><i class="fas fa-star"></i><i class="fas fa-star">
        </i><i class="fas fa-star">
        </i><i class="fas fa-star"></i>
        </td>
      
      </tr>
      <tr>
        <td> Amazon </td> <td><i class="fas fa-star"></i><i class="fas fa-star">
        </i><i class="fas fa-star">
        </i><i class="fas fa-star"></i>
        <i class="fas fa-star-half-alt"></i></td>
        <tr>
        <td> Flipkart</td> <td><i class="fas fa-star"></i><i class="fas fa-star">
        </i><i class="fas fa-star">
        </i><i class="fas fa-star"></i>
        <i class="fas fa-star"></i></td>
        
      
    </table>
</div>
</div>
  </div>

  <div style=";text-align:center;align-items:center;padding:1% ;color:white" class="col-lg-12 col-md-12 col-lg-xs">&copy; COPYRIGHT 2020 ALL RIGHTS RESERVED | CREATOR HIMANSHU KUMAR</div>
</div>

</div>
</div>
   
 </section>
 
