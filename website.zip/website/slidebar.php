
<div id="carouselExampleCaptions" class="carousel slide " data-pause="hover" data-ride="true" data-interval="6000" >
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
    <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img height=400px src="image/fish.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption  d-md-block">
        <h2 class="animate__animated animate__slideInDown  animate__delay-1s"  style="color:brown;font-weight:900" >Welcome To Onli9 Mart</h2>
        
        <p class="animate__animated animate__slideInLeft animate__delay-2s" style="color:blue;font-size:30px;font-weight:900">Your Trust
         Our Responsibility</p>
        <button class="btn btn-danger animate__animated animate__slideInLeft animate__delay-3s"><a style="text-decoration:none;color:white" href="login.php">LOG IN</a></button>
        <button class="btn btn-primary animate__animated animate__slideInRight animate__delay-4s"> <a style="text-decoration:none;color:white" href="signin.php">SIGN IN</a></button>
      </div>
    </div>
    
    </div>
  </div>
  
  <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>

</div>