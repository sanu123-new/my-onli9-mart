<!doctype html>
<html>
    <head>
<?php 

include_once("head.php");
?>
</head>
<body style="background:radial-gradient(white,blue)">
  
<?php 
include_once("nav.php");?>
<?php


$con=mysqli_connect("localhost","root","mera@sqlioplkj","online mart");
if(!$con)
die("could not connected");
if(isset($_POST["purchase"])){
$pi=$_POST["pid"];
$email=$_POST["email"];
$s="select * from addproduct where PI='$pi' && EMAIL= '$email'   " ;
$no=mysqli_query($con,$s);


    foreach($no as $rs)
    {
        ?>
        

    <div class="container " style=" text-align:center;position:relative;top:100px;">
    <div class="row">
    <input type="hidden" name="pid" value="<?php echo $rs['PI'];?>">
      <div class="col-lg-12  card-body"  width=300px height=300px  style="text-align:center;"><img  class=" zoom" width=300px height=300px  src="adminweb/product/<?php echo $rs['PPIC'] ; ?>"alt=""></div>
      <div class="col-lg-12" style="height:20px"></div>
    <div class=" col-lg-12 "><?php echo "<b>". $rs["PN"]. "</b> ";?></div>
    <div class="col-lg-12" style="height:5px"></div>
   
  
  <div class="col-lg-12" style="height:5px"></div>
  
  
  <div class="col-lg-12"   >
  <div class="row">
  <div class="col-lg-12" ><button onclick="go();"  style="margin:10px;text-align:center;width:38%;background:red;color:white;" class="btn  text-center" type="submit" > Go Back
   </button></div>
</div>

   <div class="col-lg-12"  >
  

  
 
   
   </div>
</div>
</div>
  
    </div>


    </div>
    
    </div>






<?php
    }  
}


?>


<script src="1.js"></script>
<?php
include_once("js.php");
?>

</body>

    </html>