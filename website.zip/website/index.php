<!doctype html>
<html>
    <head>
<?php 

include_once("head.php");
?>
</head>
<body >
  
<?php 
include_once("nav.php");?>

<?php
include_once("slidebar.php");
?>


<?php
include_once("indexbody.php");?>


<?php
include_once("js.php");
?>

</body>

    </html>